var dir_8dd7e1572832d3009fccb9d6fef624ee =
[
    [ "BeagleGoo.h", "_beagle_goo_8h.html", [
      [ "BeagleGoo", "struct_beagle_goo.html", "struct_beagle_goo" ],
      [ "GPIOInfo", "struct_beagle_goo_1_1_g_p_i_o_info.html", "struct_beagle_goo_1_1_g_p_i_o_info" ]
    ] ],
    [ "BeagleGooP.h", "_beagle_goo_p_8h.html", [
      [ "BeagleGooP", "class_beagle_goo_p.html", "class_beagle_goo_p" ]
    ] ]
];