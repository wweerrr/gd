var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "beaglebone", "dir_8dd7e1572832d3009fccb9d6fef624ee.html", "dir_8dd7e1572832d3009fccb9d6fef624ee" ],
    [ "device", "dir_00639e50a5e06ba932c41b2ae621276d.html", "dir_00639e50a5e06ba932c41b2ae621276d" ],
    [ "debug.h", "debug_8h.html", "debug_8h" ],
    [ "GPIOoo.h", "_g_p_i_ooo_8h.html", [
      [ "GPIOoo", "class_g_p_i_ooo.html", "class_g_p_i_ooo" ]
    ] ],
    [ "GPIOpin.h", "_g_p_i_opin_8h.html", [
      [ "GPIOpin", "class_g_p_i_opin.html", "class_g_p_i_opin" ]
    ] ],
    [ "SPI.h", "_s_p_i_8h.html", [
      [ "SPI", "class_s_p_i.html", "class_s_p_i" ]
    ] ]
];