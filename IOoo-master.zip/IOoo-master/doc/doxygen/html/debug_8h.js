var debug_8h =
[
    [ "debug", "debug_8h.html#a5ed91c6fa16b273dcf5a09956f7fa539", null ],
    [ "DEBUG_LEVEL", "debug_8h.html#ac2d33ccaf63f5d5b66552b95426c0137", null ]
];