var _beaglebone_s_p_i_8cpp =
[
    [ "SEQ_LEN", "_beaglebone_s_p_i_8cpp.html#a9bb61942a4e9c9cab56634ba82d06be9", null ],
    [ "main", "_beaglebone_s_p_i_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "setupSPI", "_beaglebone_s_p_i_8cpp.html#ae764ad6d6eb2aecacdf8c31f41c2a276", null ],
    [ "testSPI", "_beaglebone_s_p_i_8cpp.html#a5f2aa15f0f163d1b32ecb4729c0ec8e7", null ]
];