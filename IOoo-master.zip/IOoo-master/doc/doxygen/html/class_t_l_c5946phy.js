var class_t_l_c5946phy =
[
    [ "TLC5946phy", "class_t_l_c5946phy.html#acd5f2ca20ca8916c23625aca73306415", null ],
    [ "~TLC5946phy", "class_t_l_c5946phy.html#a7ed74634384c99c3b305e0c33d9ec47b", null ],
    [ "getXerr", "class_t_l_c5946phy.html#ac57ced207378247e87f025e3cb94d754", null ],
    [ "setBitsPerWord", "class_t_l_c5946phy.html#a0604df91a14451f72504f39cd379eed1", null ],
    [ "setBlank", "class_t_l_c5946phy.html#a917d05cee794f633a6775b8c509efba0", null ],
    [ "setLSBFirst", "class_t_l_c5946phy.html#a7f12198f25476c730e6838cfcd94c388", null ],
    [ "setMode", "class_t_l_c5946phy.html#a43974eb64479ebd593ea122e5f446ffa", null ],
    [ "setXhalf", "class_t_l_c5946phy.html#a11b29859983d81add34d6fb0721613a2", null ],
    [ "xfer", "class_t_l_c5946phy.html#a142002ef92f3bb22579e63b9110e6a30", null ],
    [ "active", "class_t_l_c5946phy.html#a6f0eea08d31a0209e5bc561b93a43067", null ],
    [ "blank_pin_pin", "class_t_l_c5946phy.html#a99fc1c99ddad63c7a7b15034ac9cffda", null ],
    [ "ctrl", "class_t_l_c5946phy.html#ad593ca4b96986ce8e40c833ed5ed3769", null ],
    [ "mode_pin_pin", "class_t_l_c5946phy.html#a21c925ef7ce83c48daaebb56f994a720", null ],
    [ "spi", "class_t_l_c5946phy.html#aa1cd89ab21c1ce96acc6d2cc8af4136e", null ],
    [ "xerr_pin_pin", "class_t_l_c5946phy.html#a4c79de11b56731d25e7f0f0455b960f0", null ],
    [ "xhalf_pin_pin", "class_t_l_c5946phy.html#a072b879adb9d018b4a9905b53cb497f0", null ]
];