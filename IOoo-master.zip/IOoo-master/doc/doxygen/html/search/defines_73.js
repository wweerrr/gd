var searchData=
[
  ['seq_5flen',['SEQ_LEN',['../_beaglebone_s_p_i_8cpp.html#a9bb61942a4e9c9cab56634ba82d06be9',1,'BeagleboneSPI.cpp']]],
  ['spi_5fdevice_5fpath_5fbase',['SPI_DEVICE_PATH_BASE',['../_s_p_i_8cpp.html#af4b0d9b3a7d1d818d468d10bb208a11a',1,'SPI.cpp']]]
];
