var searchData=
[
  ['read',['read',['../class_beagle_goo_p.html#a4a6ed00aa61f7d81de93cb880ba93d63',1,'BeagleGooP::read()'],['../class_h_d44780gpio_phy.html#a0a30a28c612d067c3023c4fb5f1388a0',1,'HD44780gpioPhy::read()'],['../class_h_d44780phy.html#abdee2bf5155e9915c9bb47b948edd7e1',1,'HD44780phy::read()'],['../class_g_p_i_opin.html#ac1a7a08dfd7828fc6f4384f390b75c0e',1,'GPIOpin::read()'],['../class_s_p_i.html#a001a78d9fbd2ea73b0fcb7b5efa816e0',1,'SPI::read()']]],
  ['refcounter',['refCounter',['../struct_beagle_goo_1_1_g_p_i_o_info.html#af3bbf6d94585ef4a62bd579fef8564ac',1,'BeagleGoo::GPIOInfo']]],
  ['release',['release',['../struct_beagle_goo.html#a67436fe547740cf9ff11f5942175b2fc',1,'BeagleGoo::release()'],['../class_g_p_i_ooo.html#ab8a52d0d5ef2fbb9ca92baa51174e3ee',1,'GPIOoo::release()']]],
  ['rscommand',['RScommand',['../class_h_d44780phy.html#a76851a61a3a88766704db9f31098d21fac3d8b04a4b6fa7db3d0bfc61170e1d72',1,'HD44780phy']]],
  ['rsdata',['RSdata',['../class_h_d44780phy.html#a76851a61a3a88766704db9f31098d21fa2108dbcf0cc7b6cdcbc6235a4e765654',1,'HD44780phy']]],
  ['rwread',['RWread',['../class_h_d44780phy.html#a5bf3a330184d4cfdc6297c1265ce6746a2777116400417dda3d881ec137a361fc',1,'HD44780phy']]],
  ['rwwrite',['RWwrite',['../class_h_d44780phy.html#a5bf3a330184d4cfdc6297c1265ce6746ac7b87f6864ebbc4bef3d14967ec3bc97',1,'HD44780phy']]]
];
