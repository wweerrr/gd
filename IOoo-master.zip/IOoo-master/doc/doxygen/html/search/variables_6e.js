var searchData=
[
  ['name',['name',['../struct_beagle_goo_1_1_g_p_i_o_info.html#aa887aa95188facb1a445920fb544134a',1,'BeagleGoo::GPIOInfo']]]
];
