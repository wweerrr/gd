var searchData=
[
  ['spi',['spi',['../class_t_l_c5946phy.html#aa1cd89ab21c1ce96acc6d2cc8af4136e',1,'TLC5946phy']]]
];
