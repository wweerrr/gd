var searchData=
[
  ['claim',['claim',['../struct_beagle_goo.html#aa5aa13bba2ba0bc364202c7856410463',1,'BeagleGoo::claim()'],['../class_g_p_i_ooo.html#a07164321fda879306394d7550454dbb2',1,'GPIOoo::claim(char *names[], int num)'],['../class_g_p_i_ooo.html#a8d7ac44872a6d12ad439afe4e914f07e',1,'GPIOoo::claim(char *names[], int num, gpioWriteSemantics semantics, gpioFlags flags=gpioFlagsNone)=0']]],
  ['clear',['clear',['../class_beagle_goo_p.html#a39772670c58f71b5d7e4ca9e39eb8d86',1,'BeagleGooP::clear()'],['../class_h_d44780.html#ae2a068c9f02651e55e75bfc4665186f9',1,'HD44780::clear()'],['../class_g_p_i_opin.html#abc101fb598fa749ae58743e8b2decbbc',1,'GPIOpin::clear()']]],
  ['clearbit',['clearBit',['../class_beagle_goo_p.html#a00a85a024ac1e9a3dbf04d4b065cc16a',1,'BeagleGooP::clearBit()'],['../class_g_p_i_opin.html#a7b79f39cb611f1b1e0a95c3a35dbc94b',1,'GPIOpin::clearBit()']]],
  ['close',['close',['../class_s_p_i.html#ab60d93bf6b639c0b4dad9da4f5854a94',1,'SPI']]],
  ['commit',['commit',['../class_t_l_c5946chain.html#a87c446b0aee06efcd78dfd659a8b7502',1,'TLC5946chain']]],
  ['ctrl',['ctrl',['../class_t_l_c5946phy.html#ad593ca4b96986ce8e40c833ed5ed3769',1,'TLC5946phy']]],
  ['currentdataaddress',['currentDataAddress',['../class_h_d44780gpio_phy.html#a933e313ac7a5362b6a55a3db9af337a3',1,'HD44780gpioPhy::currentDataAddress()'],['../class_h_d44780phy.html#a0e848e19d8a5c2c9605b7bf6bcc5394c',1,'HD44780phy::currentDataAddress()']]]
];
