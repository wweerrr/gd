var searchData=
[
  ['open',['open',['../class_s_p_i.html#a52ceb41efea8b56cd6c5fc20cd36ca33',1,'SPI']]]
];
