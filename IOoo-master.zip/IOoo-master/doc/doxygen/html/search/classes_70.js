var searchData=
[
  ['pru_5fdata',['pru_data',['../structpru__data.html',1,'']]]
];
