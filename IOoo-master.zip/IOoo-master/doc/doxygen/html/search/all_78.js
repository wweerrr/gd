var searchData=
[
  ['xerr_5fpin_5fpin',['xerr_pin_pin',['../class_t_l_c5946phy.html#a4c79de11b56731d25e7f0f0455b960f0',1,'TLC5946phy']]],
  ['xfer',['xfer',['../class_t_l_c5946phy.html#a142002ef92f3bb22579e63b9110e6a30',1,'TLC5946phy']]],
  ['xfer1',['xfer1',['../class_s_p_i.html#adcd3b90ca766fb1b69666cf3402726fe',1,'SPI']]],
  ['xhalf_5fpin_5fpin',['xhalf_pin_pin',['../class_t_l_c5946phy.html#a072b879adb9d018b4a9905b53cb497f0',1,'TLC5946phy']]]
];
