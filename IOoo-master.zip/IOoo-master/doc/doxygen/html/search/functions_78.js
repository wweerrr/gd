var searchData=
[
  ['xfer',['xfer',['../class_t_l_c5946phy.html#a142002ef92f3bb22579e63b9110e6a30',1,'TLC5946phy']]],
  ['xfer1',['xfer1',['../class_s_p_i.html#adcd3b90ca766fb1b69666cf3402726fe',1,'SPI']]]
];
