var searchData=
[
  ['read',['read',['../class_beagle_goo_p.html#a4a6ed00aa61f7d81de93cb880ba93d63',1,'BeagleGooP::read()'],['../class_h_d44780gpio_phy.html#a0a30a28c612d067c3023c4fb5f1388a0',1,'HD44780gpioPhy::read()'],['../class_h_d44780phy.html#abdee2bf5155e9915c9bb47b948edd7e1',1,'HD44780phy::read()'],['../class_g_p_i_opin.html#ac1a7a08dfd7828fc6f4384f390b75c0e',1,'GPIOpin::read()'],['../class_s_p_i.html#a001a78d9fbd2ea73b0fcb7b5efa816e0',1,'SPI::read()']]],
  ['release',['release',['../struct_beagle_goo.html#a67436fe547740cf9ff11f5942175b2fc',1,'BeagleGoo::release()'],['../class_g_p_i_ooo.html#ab8a52d0d5ef2fbb9ca92baa51174e3ee',1,'GPIOoo::release()']]]
];
