var searchData=
[
  ['host',['host',['../struct____channel__to__host__map.html#a6e47ff59629590078c2c6c6ae715bbcf',1,'__channel_to_host_map']]],
  ['host_5fenable_5fbitmask',['host_enable_bitmask',['../struct____pruss__intc__initdata.html#a65a942ffc8d6850954442f7e5252374d',1,'__pruss_intc_initdata']]]
];
