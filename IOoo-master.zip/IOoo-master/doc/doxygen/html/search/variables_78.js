var searchData=
[
  ['xerr_5fpin_5fpin',['xerr_pin_pin',['../class_t_l_c5946phy.html#a4c79de11b56731d25e7f0f0455b960f0',1,'TLC5946phy']]],
  ['xhalf_5fpin_5fpin',['xhalf_pin_pin',['../class_t_l_c5946phy.html#a072b879adb9d018b4a9905b53cb497f0',1,'TLC5946phy']]]
];
