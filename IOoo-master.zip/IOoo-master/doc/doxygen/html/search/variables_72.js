var searchData=
[
  ['refcounter',['refCounter',['../struct_beagle_goo_1_1_g_p_i_o_info.html#af3bbf6d94585ef4a62bd579fef8564ac',1,'BeagleGoo::GPIOInfo']]]
];
