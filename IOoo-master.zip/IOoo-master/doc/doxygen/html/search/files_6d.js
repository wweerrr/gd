var searchData=
[
  ['memmapped_5foe_5ftext_2ec',['memmapped_oe_text.c',['../memmapped__oe__text_8c.html',1,'']]]
];
