var searchData=
[
  ['beaglegoo',['BeagleGoo',['../struct_beagle_goo.html',1,'']]],
  ['beaglegoop',['BeagleGooP',['../class_beagle_goo_p.html',1,'']]]
];
