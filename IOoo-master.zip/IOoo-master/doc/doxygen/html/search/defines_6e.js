var searchData=
[
  ['num_5fpru_5fchannels',['NUM_PRU_CHANNELS',['../prussdrv_8h.html#acae0799208c38d548a07e381da701129',1,'prussdrv.h']]],
  ['num_5fpru_5fhostirqs',['NUM_PRU_HOSTIRQS',['../prussdrv_8h.html#a4c7e64d7f491e8e88febed14aee6cfe0',1,'prussdrv.h']]],
  ['num_5fpru_5fhosts',['NUM_PRU_HOSTS',['../prussdrv_8h.html#a8fcba73c3a4c1e10f3b8d082439291cb',1,'prussdrv.h']]],
  ['num_5fpru_5fsys_5fevts',['NUM_PRU_SYS_EVTS',['../prussdrv_8h.html#a5e00b7de7e11a59dbc6bf36ecd4c67fb',1,'prussdrv.h']]]
];
