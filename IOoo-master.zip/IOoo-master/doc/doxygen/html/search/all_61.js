var searchData=
[
  ['active',['active',['../struct_beagle_goo.html#a64e92bad467b29cb868bec64d1f6be6f',1,'BeagleGoo::active()'],['../class_t_l_c5946phy.html#a6f0eea08d31a0209e5bc561b93a43067',1,'TLC5946phy::active()'],['../class_g_p_i_opin.html#ab51fd28869cad5b9fdb38a983cb2d1c5',1,'GPIOpin::active()']]],
  ['address_5fbits',['ADDRESS_BITS',['../_h_d44780gpio_phy_8cpp.html#a3128e6392b3cbdc1f9a4b7167feb9075',1,'HD44780gpioPhy.cpp']]],
  ['addrs',['addrs',['../struct_beagle_goo.html#a13b31f0a40c07bd0ca8c9d9fa51ae60a',1,'BeagleGoo']]]
];
