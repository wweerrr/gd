var searchData=
[
  ['tchannel_5fto_5fhost_5fmap',['tchannel_to_host_map',['../prussdrv_8h.html#ae6ce5bff432f557878843c17ad0ce140',1,'prussdrv.h']]],
  ['tpruss_5fintc_5finitdata',['tpruss_intc_initdata',['../prussdrv_8h.html#a8e3a0e7d2cb107195d5c3ba82f329b8a',1,'prussdrv.h']]],
  ['tsysevt_5fto_5fchannel_5fmap',['tsysevt_to_channel_map',['../prussdrv_8h.html#af5611a9f693ff52c6da02352010f013a',1,'prussdrv.h']]]
];
