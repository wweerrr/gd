var searchData=
[
  ['name',['name',['../struct_beagle_goo_1_1_g_p_i_o_info.html#aa887aa95188facb1a445920fb544134a',1,'BeagleGoo::GPIOInfo']]],
  ['namepin',['namePin',['../class_beagle_goo_p.html#a7c5b14071a87506c912b6d14f139136f',1,'BeagleGooP::namePin()'],['../class_g_p_i_opin.html#a3feb6f38bd934e63d0704c9e178b443e',1,'GPIOpin::namePin()']]],
  ['namepins',['namePins',['../class_beagle_goo_p.html#a716e0b3664ed88ad427b329524311e03',1,'BeagleGooP::namePins()'],['../class_g_p_i_opin.html#a6d11afb8376b7ea7c5f7996fc364f64a',1,'GPIOpin::namePins()']]]
];
