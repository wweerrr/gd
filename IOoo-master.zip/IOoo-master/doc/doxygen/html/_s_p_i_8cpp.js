var _s_p_i_8cpp =
[
    [ "MAX_PATH_LEN", "_s_p_i_8cpp.html#abdd33f362ae3bbdacb5de76473aa8a2f", null ],
    [ "SPI_DEVICE_PATH_BASE", "_s_p_i_8cpp.html#af4b0d9b3a7d1d818d468d10bb208a11a", null ]
];