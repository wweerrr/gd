var struct____sysevt__to__channel__map =
[
    [ "channel", "struct____sysevt__to__channel__map.html#a1f3378ae547bef32f0117071e64d8312", null ],
    [ "sysevt", "struct____sysevt__to__channel__map.html#a5e77be482e90c245ccceee02e636fcfa", null ]
];