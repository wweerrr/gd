var tlc5946_8cpp =
[
    [ "main", "tlc5946_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "setupSPI", "tlc5946_8cpp.html#ae764ad6d6eb2aecacdf8c31f41c2a276", null ]
];