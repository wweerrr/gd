var class_s_p_i =
[
    [ "SPI", "class_s_p_i.html#a2ba081c29fbdecc704c6bf00b24d5205", null ],
    [ "~SPI", "class_s_p_i.html#a6babebf1ea3e8ff0330f43a3e2312ac4", null ],
    [ "close", "class_s_p_i.html#ab60d93bf6b639c0b4dad9da4f5854a94", null ],
    [ "open", "class_s_p_i.html#a52ceb41efea8b56cd6c5fc20cd36ca33", null ],
    [ "read", "class_s_p_i.html#a001a78d9fbd2ea73b0fcb7b5efa816e0", null ],
    [ "setBitsPerWord", "class_s_p_i.html#a4e6b7a9b89809663c91712ceff00920b", null ],
    [ "setClockPhase", "class_s_p_i.html#acc43a43a985c6e73723852d621324ef8", null ],
    [ "setClockPolarity", "class_s_p_i.html#afad281dadda690a5bb1ad456c2ddb924", null ],
    [ "setLSBFirst", "class_s_p_i.html#aedcab28ad20f691db0f3450ed825fd69", null ],
    [ "setMode", "class_s_p_i.html#a81ff077c6af077ef9d1ee2d56a8a310b", null ],
    [ "setSpeed", "class_s_p_i.html#a3de287340d081fc813fd21269b014183", null ],
    [ "write", "class_s_p_i.html#a7349053056a1e712eb6f5c1f122186d0", null ],
    [ "xfer1", "class_s_p_i.html#adcd3b90ca766fb1b69666cf3402726fe", null ]
];