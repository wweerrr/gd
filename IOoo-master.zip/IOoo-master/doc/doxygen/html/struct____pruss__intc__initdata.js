var struct____pruss__intc__initdata =
[
    [ "channel_to_host_map", "struct____pruss__intc__initdata.html#a2d70c1e765537925835df6218575accc", null ],
    [ "host_enable_bitmask", "struct____pruss__intc__initdata.html#a65a942ffc8d6850954442f7e5252374d", null ],
    [ "sysevt_to_channel_map", "struct____pruss__intc__initdata.html#a6f5f3e8c82094df65ca5d4a0b6ad93d9", null ],
    [ "sysevts_enabled", "struct____pruss__intc__initdata.html#aa2c01e019376c32180ce166302f69ee6", null ]
];