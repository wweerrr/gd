var struct_beagle_goo_1_1_g_p_i_o_info =
[
    [ "bitNum", "struct_beagle_goo_1_1_g_p_i_o_info.html#a31959d0d24502777f3286e7ccb9c8e62", null ],
    [ "flags", "struct_beagle_goo_1_1_g_p_i_o_info.html#afeb1ff6e6ad263177a9b1bb82e7a0043", null ],
    [ "gpioNum", "struct_beagle_goo_1_1_g_p_i_o_info.html#a870d8a3d36706dd366eea2299ccb29fd", null ],
    [ "name", "struct_beagle_goo_1_1_g_p_i_o_info.html#aa887aa95188facb1a445920fb544134a", null ],
    [ "refCounter", "struct_beagle_goo_1_1_g_p_i_o_info.html#af3bbf6d94585ef4a62bd579fef8564ac", null ]
];