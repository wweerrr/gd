var struct____channel__to__host__map =
[
    [ "channel", "struct____channel__to__host__map.html#aba81cea787f132fd67e37d429e869c9f", null ],
    [ "host", "struct____channel__to__host__map.html#a6e47ff59629590078c2c6c6ae715bbcf", null ]
];