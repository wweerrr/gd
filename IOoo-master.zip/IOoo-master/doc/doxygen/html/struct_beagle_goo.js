var struct_beagle_goo =
[
    [ "GPIOInfo", "struct_beagle_goo_1_1_g_p_i_o_info.html", "struct_beagle_goo_1_1_g_p_i_o_info" ],
    [ "BeagleGoo", "struct_beagle_goo.html#a06b2b0e2d3b22016edb11b515fad8f0a", null ],
    [ "~BeagleGoo", "struct_beagle_goo.html#a19514c99eb2f17004ad19ffb2cd0b1d5", null ],
    [ "_findGpio", "struct_beagle_goo.html#a2870e374462486c977ed462d169bbc07", null ],
    [ "claim", "struct_beagle_goo.html#aa5aa13bba2ba0bc364202c7856410463", null ],
    [ "release", "struct_beagle_goo.html#a67436fe547740cf9ff11f5942175b2fc", null ],
    [ "BeagleGooP", "struct_beagle_goo.html#a3c53b8008fd7b4a4dc43d5c025cfb91f", null ],
    [ "GPIOoo", "struct_beagle_goo.html#ad655c01bbbf0f8f066500cb0ea296455", null ],
    [ "active", "struct_beagle_goo.html#a64e92bad467b29cb868bec64d1f6be6f", null ],
    [ "gpioFd", "struct_beagle_goo.html#a1d4a232a0dbb10d38249e239c7e04788", null ],
    [ "gpios", "struct_beagle_goo.html#aaa05aec2adfcadae3912e861ae35d50b", null ]
];