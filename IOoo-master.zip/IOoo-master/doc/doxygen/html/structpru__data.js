var structpru__data =
[
    [ "prumem", "structpru__data.html#a29e00509c51ee8e22747b609333dfe1c", null ]
];